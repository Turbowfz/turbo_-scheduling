#!/system/bin/sh

MODDIR="${0%/*}"
SCRIPTS_DIR="$MODDIR/scripts"
LOG_DIR="$MODDIR/log"
LOG_FILE="$LOG_DIR/boot.log"

mkdir -p "$LOG_DIR"
. "$SCRIPTS_DIR/common.sh"

# ── 日志清空: 每次开机重新开始记录 (重启后日志为空) ──
log_reset "$LOG_DIR"

# ── bin 执行位自愈 (个别安装器环境 chmod 不残留, 缺执行位时 root 也无法 exec) ──
chmod 755 "$MODDIR/bin/cosa" 2>/dev/null
# ── SQLite 库自愈: 用系统的 /system/lib64/libsqlite.so, 链接丢了就补上 ──
# 符号链接丢了就补上, 否则 cosa 连启动都起不来 (覆盖安装/模块目录被重建时可能丢)
[ -e "$MODDIR/bin/libsqlite3.so" ] || ln -sf /system/lib64/libsqlite.so "$MODDIR/bin/libsqlite3.so" 2>/dev/null

# ── 机型门禁 (第二道): 非骁龙 8 系不启动任何功能, 并请求管理器移除模块 ──
# 安装器会拦, 但拦不住"手动塞模块目录 + 造标志"这类绕过; 这里是兜底。
# remove 是 KernelSU/Magisk 的标准标记文件, 下次开机管理器自动移除模块。
if ! is_supported_soc; then
  log "[门禁] 非骁龙 8 系机型, 停用本模块 (已写 remove 标记, 下次开机由管理器移除)"
  touch "$MODDIR/remove" 2>/dev/null
  rm -rf "$FLAG_DIR" 2>/dev/null
  sed -i "s/^description=.*/description=机型不支持, 已停用/" "$MODDIR/module.prop" 2>/dev/null
  exit 0
fi

# ── description 开机自愈: 安装时的 sed 改的是解包临时目录, 会被 KSU 用 zip 原始
#    module.prop 覆盖 (永远显示"重启后生效")。每次开机按标志文件刷新一次 ──
update_description() {
  local desc
  if [ -f "$FLAG_DIR/rc_installed" ] && [ -f "$FLAG_DIR/sc_installed" ]; then
    desc="云控注入 + 二改调度($(cat "$FLAG_DIR/config_type" 2>/dev/null))"
  elif [ -f "$FLAG_DIR/rc_installed" ]; then
    desc="云控注入"
  elif [ -f "$FLAG_DIR/sc_installed" ]; then
    desc="二改调度($(cat "$FLAG_DIR/config_type" 2>/dev/null))"
  else
    desc="无任何功能，建议卸载"
  fi
  sed -i "s/^description=.*/description=$desc/" "$MODDIR/module.prop" 2>/dev/null
}
update_description

# 等待开机完成 + CE 解锁 (数据目录可读)。
# 注意: 手机重启后一直锁屏时 CE 要到首次解锁才就绪 (sys.user.0.ce_available 之前为 false) —
# 上限给到 30 分钟, 否则用户"重启就揣兜里"的场景会直接放弃部署与注入, 且本开机不再重试。
wait_boot_ready() {
  w=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$w" -lt 600 ]; do sleep 1; w=$((w + 1)); done
  w=0
  while [ "$w" -lt 1800 ]; do
    [ "$(getprop sys.user.0.ce_available)" = "true" ] && return 0
    if [ -d "$VT_FILES" ] || [ -d /data/data/com.oplus.cosa ]; then return 0; fi   # 目录可读 = 已解锁
    sleep 5; w=$((w + 5))
  done
  log "[等待] CE解锁超时 (30分钟), 仍继续尝试"
}

log "========================================="
log "Turbo调度 开机服务启动"

# ── Scene 调度 ──
if [ -f "$FLAG_DIR/sc_installed" ]; then
  config_type=$(cat "$FLAG_DIR/config_type" 2>/dev/null)

  log "[Scene] 等待开机完成... (类型: $config_type)"
  wait_boot_ready
  prepare_scene_dir 60 || log "[Scene] 警告: 目录未就绪, 仍尝试部署"
  sleep 5
  log "[Scene] 目录就绪, 开始部署"
  sh "$SCRIPTS_DIR/scene_config.sh" deploy

  # 等 Scene 进程起来 (最多120s) 再动官方调度, 避免与 Scene 启动交叉; 起来后留 5s 读配置
  _sw=0
  while ! pidof com.omarea.vtools >/dev/null 2>&1 && [ "$_sw" -lt 120 ]; do
    sleep 2; _sw=$((_sw + 2))
  done
  [ "$_sw" -ge 120 ] && log "[Scene] 等待Scene进程超时 (120s), 按原计划继续"
  sleep 5
  if [ "$config_type" = "generic" ]; then
    log "[Scene] 通用版: 停止官方调度服务"
    stop_official
  else
    log "[Scene] oplus版: 保持官方调度服务"
    start_official
  fi

  log "[Scene] 加固 executor 权限"
  # 只在真的不一致时才动: sed -i 会重写文件, chmod 同值也会更新 ctime —— 每开机无谓地摸一遍
  # 整棵缓存树的元数据既费时, 又是"无谓文件事件触发 Scene 热加载"的老坑
  if grep -q 'chmod 755 "$script_path"' "$VT_FILES/kr-script/executor.sh" 2>/dev/null; then
    sed -i 's/chmod 755 "$script_path"/chmod 777 "$script_path"/g' "$VT_FILES/kr-script/executor.sh" 2>/dev/null
  fi
  perm_is "$VT_FILES/kr-script/executor.sh" "555" || chmod 555 "$VT_FILES/kr-script/executor.sh" 2>/dev/null
  perm_is "$VT_FILES/kr-script/cache" "777" || chmod 777 "$VT_FILES/kr-script/cache" 2>/dev/null
  find "$VT_FILES/kr-script/cache" -type f -not -perm -777 -exec chmod 777 {} + 2>/dev/null
  find "$VT_FILES/kr-script/cache" -type d -not -perm -777 -exec chmod 777 {} + 2>/dev/null

  log "[Scene] 初始化完成"
else
  # 未启用二改调度: 老版本留下过 backup/ (有的还是"整目录备份", 上百个 .so/.dex/图标),
  # 只装云控的用户用不到 —— 开机顺手清掉, 不必等下次重装模块。
  # drop_scene_backup 只在 Scene 当前仍是模块改过的配置时才把原版还回 (见 common.sh)
  if [ -d "$FLAG_DIR/backup" ]; then
    log "[Scene] 未启用二改调度, 清理遗留的 Scene 备份"
    drop_scene_backup
  fi
fi

# ── 云控注入 ──
if [ -f "$FLAG_DIR/rc_installed" ]; then
  log "[云控] 后台服务启动"

  {
    echo "[$(date '+%m-%d %T')] 云控服务启动"
    wait_boot_ready
    start_official   # 开机未完成时 start 可能失败, 放在 wait 之后

    # DB 就绪即匹配+注入 (最长等 30 分钟: 手机重启后一直锁屏时数据库要到解锁后才可读,
    # 上限太短会静默放弃本次注入; 轮询 10 秒一次, 每 2 分钟记录一条进度避免刷屏)
    MAX_WAIT=1800
    WAIT_INTERVAL=10
    elapsed=0
    found=0

    while [ $elapsed -lt $MAX_WAIT ]; do
      DB=$(find_db)
      if [ -n "$DB" ]; then
        echo "[$(date '+%m-%d %T')] 数据库就绪: $DB"
        sleep 10
        echo "[$(date '+%m-%d %T')] 执行包名匹配..."
        sh "$SCRIPTS_DIR/pkg_matcher.sh"
        echo "[$(date '+%m-%d %T')] 开始注入..."
        sh "$SCRIPTS_DIR/cloud_ctrl.sh" inject
        echo "[$(date '+%m-%d %T')] 注入完成 (新版工具自带保护触发器, 无需守护)"
        found=1
        break
      fi
      sleep $WAIT_INTERVAL
      elapsed=$((elapsed + WAIT_INTERVAL))
      [ $((elapsed % 120)) -eq 0 ] && echo "[$(date '+%m-%d %T')] 等待数据库 (未解锁时不可读)... ${elapsed}s"
    done

    # 仅在真正超时 (未找到数据库) 时输出错误, 注入成功不再误报
    [ "$found" = "0" ] && echo "[$(date '+%m-%d %T')] 错误: 超时未找到数据库"
  } >> "$LOG_FILE" 2>&1 &
fi

log "========================================="

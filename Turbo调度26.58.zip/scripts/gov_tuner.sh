#!/system/bin/sh

MODPATH="${0%/*/*}"
SCRC_DIR="/data/adb/scrc"
LOG_DIR="$MODPATH/log"
LOG_FILE="$LOG_DIR/gov.log"

TARGET_GOV="walt"
WHITELIST="walt,scx"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

# SCRC 方式: SM8650 + oplus Scene + 云控 才启用
should_run() {
  [ -f "$SCRC_DIR/rc_installed" ] || return 1
  [ -f "$SCRC_DIR/sc_installed" ] || return 1
  [ "$(cat "$SCRC_DIR/config_type" 2>/dev/null)" = "oplus" ] || return 1
  local p=$(getprop ro.board.platform)
  local m=$(getprop ro.soc.model)
  case "$p" in
    pineapple|sun) ;;
    *) case "$m" in
         *8650*|*8750*) ;;
         *) return 1 ;;
       esac ;;
  esac
  return 0
}

in_whitelist() {
  local gov="$1"
  local saved_ifs="$IFS"
  IFS=','
  for w in $WHITELIST; do
    [ "$gov" = "$w" ] && { IFS="$saved_ifs"; return 0; }
  done
  IFS="$saved_ifs"
  return 1
}

should_run || { log "条件不满足，跳过调速器切换"; exit 0; }

log "=== 调速器切换开始 ==="
log "目标: $TARGET_GOV | 白名单: $WHITELIST"

switched=0
skipped=0
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -f "$policy/scaling_governor" ] || continue
  cpu=$(basename "$policy" | sed 's/policy//')
  cur=$(cat "$policy/scaling_governor" 2>/dev/null)
  [ -z "$cur" ] && continue

  if in_whitelist "$cur"; then
    log "跳过 $cpu: $cur (白名单)"
    skipped=$((skipped + 1))
  else
    echo "$TARGET_GOV" > "$policy/scaling_governor" 2>/dev/null && {
      switched=$((switched + 1))
      log "切换 $cpu: $cur → $TARGET_GOV"
    } || {
      log "失败 $cpu: $cur → $TARGET_GOV"
    }
  fi
done

log "结果: 切换$switched / 跳过$skipped"
log "=== 调速器切换结束 ==="

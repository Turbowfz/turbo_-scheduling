#!/system/bin/sh

MODE="${1:-inject}"
MODPATH="${2:-${0%/*/*}}"
CONFIG_TYPE="${3:-generic}"

SQLITE="$MODPATH/tool/sqlite3"
JQ="$MODPATH/tool/jq"
JSON_DIR="$MODPATH/json"
SCRC_DIR="/data/adb/scrc"
LOG_DIR="$MODPATH/log"
LOG_FILE="$LOG_DIR/cloud.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

find_db() {
  if [ -f "/data/data/com.oplus.cosa/databases/db_game_database" ]; then
    echo "/data/data/com.oplus.cosa/databases/db_game_database"
  elif [ -f "/data/user_de/0/com.oplus.cosa/databases/db_game_database" ]; then
    echo "/data/user_de/0/com.oplus.cosa/databases/db_game_database"
  fi
}

enable_oplus_services() {
  setprop persist.sys.oplus.gameswitch.enable 1
  setprop persist.sys.oiface.enable 1
  setprop persist.sys.horae.enable 1
  start oiface 2>/dev/null
  start horae 2>/dev/null
  start gameopt_hal_service-1-0 2>/dev/null
  start vendor.urcc-hal-aidl 2>/dev/null

  {
    pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaHyperBoostService
    pm enable com.oplus.cosa/com.oplus.cosa.gpalibrary.service.GPAService
    pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.HyperBoostService
    pm enable com.oplus.appbooster/com.oplus.appbooster.service.OptimizeService
    pm enable com.oplus.appbooster/androidx.room.MultiInstanceInvalidationService
    pm enable com.oplus.cosa/com.oplus.cosa.feature.ScreenPerceptionService
    pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaGameSdkService
    pm enable com.oplus.cosa/com.oplus.cosa.service.COSAService
    pm enable com.oplus.cosa/com.oplus.cosa.service.GameDaemonService
    pm enable com.oplus.cosa/androidx.room.MultiInstanceInvalidationService
    pm enable com.oplus.cosa/androidx.work.impl.foreground.SystemForegroundService
    pm enable com.oplus.cosa/androidx.work.impl.background.systemalarm.SystemAlarmService
    pm enable com.oplus.cosa/com.oplus.cosa.testlibrary.service.COSATesterService
    pm enable com.oplus.cosa/androidx.work.impl.background.systemjob.SystemJobService
    pm enable com.oplus.cosa/com.oplus.cosa.gamemanagersdk.CosaAMTService
    pm enable com.oplus.cosa/com.oplus.cosa.service.GameEventService
  } >/dev/null 2>&1
}

inject_configs() {
  log "=== 注入模式开始 ==="

  DB=$(find_db)
  [ -z "$DB" ] && { echo "! 未找到数据库"; log "错误: 未找到数据库"; return 1; }
  log "数据库: $DB"

  [ -d "$JSON_DIR" ] || { echo "! JSON目录缺失"; log "错误: JSON目录缺失"; return 1; }
  json_count=$(ls "$JSON_DIR"/*.json 2>/dev/null | wc -l)
  [ "$json_count" -eq 0 ] && { echo "  ! 未检测到支持的游戏"; echo "    手机未安装受支持的游戏（原神/崩铁/绝区零/PUBG 等）"; log "JSON目录为空: 无匹配游戏"; return 1; }
  log "待注入: $json_count 个配置文件"

  total=0; success=0; fail=0

  echo "  开始注入..."
  echo ""
  for json in "$JSON_DIR"/*.json; do
    [ -f "$json" ] || continue
    total=$((total + 1))
    pkg=$(basename "$json" .json)

    "$SQLITE" "$DB" "DELETE FROM PackageConfigBean WHERE Package_Name = '$pkg';" 2>/dev/null

    columns=$("$JQ" -r 'keys_unsorted | join(",")' "$json" 2>/dev/null) || { fail=$((fail + 1)); echo "  x $pkg"; log "失败: $pkg 列名解析失败"; continue; }

    values=$("$JQ" -r '
      [to_entries[] |
      if .value == null then "NULL"
      elif (.value | type) == "string" then
          "\"" + (.value | gsub("\""; "\"\"")) + "\""
      else
          .value | tojson | gsub("\""; "\"\"") | "\"" + . + "\""
      end] | join(",")' "$json" 2>/dev/null) || { fail=$((fail + 1)); echo "  x $pkg"; log "失败: $pkg 值解析失败"; continue; }

    if echo "INSERT INTO PackageConfigBean (Package_Name, $columns) VALUES (\"$pkg\", $values);" | "$SQLITE" "$DB" 2>/dev/null; then
      success=$((success + 1))
      echo "  + $pkg"
    else
      fail=$((fail + 1))
      echo "  x $pkg"
      log "失败: $pkg SQL写入失败"
    fi
  done

  setprop persist.sys.oplus.gameswitch.enable 0
  sleep 1
  killall com.oplus.cosa 2>/dev/null
  sleep 2
  setprop persist.sys.oplus.gameswitch.enable 1
  start gameopt_hal_service-1-0 2>/dev/null
  start vendor.urcc-hal-aidl 2>/dev/null

  log "注入完成: 总$total / 成功$success / 失败$fail"
  echo "  结果: 总数 $total / 成功 $success / 失败 $fail"

  log "=== 注入模式结束 ==="
  return 0
}

has_scx_hmbird() {
  local gov_file=$(ls /sys/devices/system/cpu/cpufreq/policy*/scaling_available_governors 2>/dev/null | head -n 1)
  [ -n "$gov_file" ] && grep -qEw "scx|hmbird" "$gov_file"
}

setup_mode() {
  log "=== 安装模式开始 ==="

  if ! has_scx_hmbird; then
    echo "  ! 未检测到 scx/hmbird 调速器"
    echo "    云控注入需要风驰游戏内核或 GKI 内核支持"
    rm -f "$SCRC_DIR/rc_installed"
    log "错误: 缺少 scx/hmbird 调速器, 安装中止"
    return 1
  fi
  log "调速器检查通过 (scx/hmbird)"
  echo ""
  echo "  ┌──────────────────────────────┐"
  echo "  │      风驰游戏内核使用说明     │"
  echo "  ├──────────────────────────────┤"
  echo "  │ 1. 确保 oiface, gameopt,     │"
  echo "  │    urcc 相关组件存活          │"
  echo "  │ 2. 确保风驰存活后刷入        │"
  echo "  │    群文件调度及风驰文件      │"
  echo "  │ 3. 进入游戏打开 Scene 查看   │"
  echo "  │    调速器是否为 scx          │"
  echo "  └──────────────────────────────┘"

  DB=$(find_db)

  if [ -z "$DB" ]; then
    echo "  ! 未找到应用增强服务数据库"
    echo "    请确保:"
    echo "    1. 已启用游戏助手和应用增强服务"
    echo "    2. 至少打开过一次游戏中心"
    rm -f "$SCRC_DIR/rc_installed"
    log "错误: 未找到DB, 安装失败"
    return 1
  fi

  DB_SIZE=$(du -sh "$DB" | awk '{print $1}')
  echo "  + 数据库已就绪 ($DB_SIZE)"
  log "数据库就绪: $DB ($DB_SIZE)"

  mkdir -p "$SCRC_DIR"
  touch "$SCRC_DIR/rc_installed"

  if [ -f "$SCRC_DIR/sc_installed" ] && [ "$CONFIG_TYPE" = "oplus" ]; then
    :
  fi

  enable_oplus_services
  echo "  + 官方调度组件已就绪"
  echo "  - 匹配已安装游戏..."
  sh "$MODPATH/scripts/pkg_matcher.sh"
  echo "  + 云控注入安装完成，重启后生效"
  log "安装完成"
  log "=== 安装模式结束 ==="
  return 0
}

case "$MODE" in
  setup)
    setup_mode
    ;;
  inject)
    inject_configs
    ;;
  *)
    echo "用法: $0 {setup|inject} [MODPATH] [CONFIG_TYPE]"
    exit 1
    ;;
esac

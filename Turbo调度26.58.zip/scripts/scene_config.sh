#!/system/bin/sh

MODE="${1:-install}"

MODPATH="${2:-${0%/*/*}}"
SCRIPTS_DIR="${0%/*}"
SCRC_DIR="/data/adb/scrc"
VT_FILES="/data/data/com.omarea.vtools/files"
GOV_PATH=$(ls /sys/devices/system/cpu/cpufreq/policy*/scaling_available_governors 2>/dev/null | head -n 1)
CONFIG_DIR="$MODPATH/config"
LOG_DIR="$MODPATH/log"
LOG_FILE="$LOG_DIR/scene.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

is_oplus() {
  [ -n "$GOV_PATH" ] && grep -qEw "scx|hmbird" "$GOV_PATH"
}

get_soc_dir() {
  local p=$(getprop ro.board.platform)
  local m=$(getprop ro.soc.model)
  case "$p" in
    sun)      echo "8elite" ;;
    pineapple) echo "8gen3" ;;
    *) case "$m" in
         *8750*) echo "8elite" ;;
         *)      echo "8gen3" ;;
       esac ;;
  esac
}

get_key() {
  (timeout 3 getevent -qlc 1) 2>/dev/null | grep -E 'KEY_VOLUMEUP.*DOWN|KEY_VOLUMEDOWN.*DOWN' | awk '{print $3}' | head -n1
}

wait_key() {
  while :; do
    key=$(get_key)
    [ -n "$key" ] && echo "$key" && return
    sleep 0.1
  done
}

create_backup() {
  BACKUP_DIR="$SCRC_DIR/backup"
  mkdir -p "$BACKUP_DIR"
  if [ -z "$(ls "$BACKUP_DIR"/*.json 2>/dev/null)" ] && [ -d "$VT_FILES" ]; then
    chmod -R 777 "$VT_FILES" 2>/dev/null
    cp -af "$VT_FILES/." "$BACKUP_DIR/" 2>/dev/null
    chown -R system:system "$VT_FILES" 2>/dev/null
    log "备份Scene原始配置完成"
  fi
}

deploy_config() {
  local config_type="$1"
  local soc_dir=$(get_soc_dir)
  local src_dir="$MODPATH/$soc_dir/${config_type}_config"

  [ -d "$src_dir" ] || { echo "  ! 配置源缺失: $src_dir"; log "错误: 配置源缺失 $src_dir"; return 1; }

  mkdir -p "$CONFIG_DIR"
  cp -rf "$src_dir/." "$CONFIG_DIR/"
  echo "  + Scene配置已部署 ($config_type)"
  log "Scene配置已部署: $config_type"

  mkdir -p "$SCRC_DIR"
  touch "$SCRC_DIR/sc_installed"
  echo "$config_type" > "$SCRC_DIR/config_type"

  return 0
}

copy_to_scene() {
  [ -d "$CONFIG_DIR" ] || { log "错误: config目录缺失"; return 1; }

  local count=0
  for file in manifest.json _ShortVideo.json profile.json categories.json _Games.json; do
    [ -f "$VT_FILES/$file" ] && chmod 755 "$VT_FILES/$file"
    [ -f "$CONFIG_DIR/$file" ] && { cp -f "$CONFIG_DIR/$file" "$VT_FILES/"; count=$((count + 1)); }
    [ -f "$VT_FILES/$file" ] && chmod 555 "$VT_FILES/$file"
  done

  log "Scene配置覆盖完成 ($count 个文件)"
}

wait_scene_dir() {
  local waited=0
  while [ ! -d "$VT_FILES" ]; do
    sleep 2; waited=$((waited + 2))
    [ $waited -ge 60 ] && { log "等待Scene目录超时"; return 1; }
  done
  chown system:system "$VT_FILES"
  chmod 755 "$VT_FILES"
  log "Scene目录就绪 (等待${waited}s)"
}

install_mode() {
  if [ ! -d "$VT_FILES" ]; then
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  ! 未检测到 Scene 配置目录"
    echo "    请先安装正版 Scene9 并开启 HP 调度"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log "Scene目录不存在，跳过Scene调度"

    if is_oplus; then
      echo ""
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  检测到支持风驰的 oplus 设备"
      echo "  是否单独安装云控配置注入？"
      echo "  (仅注入游戏调度，不使用Scene)"
      echo "  [音量+] 安装  [音量-] 取消"
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
      key=$(wait_key)
      if [ "$key" = "KEY_VOLUMEUP" ]; then
        sh "$SCRIPTS_DIR/cloud_ctrl.sh" setup "$MODPATH"
      else
        rm -f "$SCRC_DIR/rc_installed"
        echo "  - 已跳过"
        log "跳过云控注入"
      fi
    fi
    return 1
  fi

  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  是否启用二改Scene调度？"
  echo "  (通过替换 Scene 调度配置文件实现)"
  echo "  [音量+] 启用  [音量-] 跳过"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

  key=$(wait_key)
  if [ "$key" != "KEY_VOLUMEUP" ]; then
    echo "  - 已跳过二改调度"
    rm -f "$SCRC_DIR/sc_installed"
    log "用户跳过二改调度"

    if is_oplus; then
      echo ""
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  检测到支持风驰的 oplus 设备"
      echo "  是否单独安装云控配置注入？"
      echo "  (仅注入游戏调度，不使用Scene)"
      echo "  [音量+] 安装  [音量-] 取消"
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
      key=$(wait_key)
      if [ "$key" = "KEY_VOLUMEUP" ]; then
        sh "$SCRIPTS_DIR/cloud_ctrl.sh" setup "$MODPATH"
      else
        rm -f "$SCRC_DIR/rc_installed"
        echo "  - 已跳过"
        log "跳过云控注入"
      fi
    fi
    return 1
  fi

  create_backup

  if is_oplus; then
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  检测到支持风驰游戏内核的 oplus 设备"
    echo "  请选择调度版本："
    echo "  [音量+] oplus版"
    echo "     仅调整日用调度，游戏使用官方调度"
    echo "     可搭配云控注入使用 ✓"
    echo "  [音量-] 通用版"
    echo "     日用+游戏全部使用二改调度"
    echo "     不可搭配云控注入 ✗"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

    key=$(wait_key)
    if [ "$key" = "KEY_VOLUMEUP" ]; then
      echo "  + 已选择: oplus版"
      deploy_config "oplus" || return 1

      echo ""
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"
      echo "  是否启用云控注入？"
      echo "  (将官方游戏调度写入应用增强服务)"
      echo "  ! 需要保证官方调度组件完整"
      echo "  [音量+] 启用  [音量-] 跳过"
      echo "━━━━━━━━━━━━━━━━━━━━━━━━━━"

      key=$(wait_key)
      if [ "$key" = "KEY_VOLUMEUP" ]; then
        sh "$SCRIPTS_DIR/cloud_ctrl.sh" setup "$MODPATH" "oplus"
      else
        rm -f "$SCRC_DIR/rc_installed"
        echo "  - 已跳过云控注入"
        echo "  ! 注意: 需保证官方调度组件完整方可生效"
        log "oplus版, 用户跳过云控注入"
      fi
    else
      echo "  + 已选择: 通用版"
      deploy_config "generic" || return 1
      log "通用版, 询问AsoulOpt"
      sh "$SCRIPTS_DIR/asoul_install.sh" "$MODPATH"
    fi
  else
    echo "  - 当前设备不支持风驰，自动选择通用版"
    deploy_config "generic" || return 1
    log "非oplus设备, 自动通用版"
    sh "$SCRIPTS_DIR/asoul_install.sh" "$MODPATH"
  fi

  return 0
}

case "$MODE" in
  install)
    log "=== 安装模式开始 ==="
    install_mode
    log "=== 安装模式结束 ==="
    ;;
  deploy)
    log "=== 部署模式开始 ==="
    wait_scene_dir || { log "部署中止: Scene目录不存在"; exit 1; }
    copy_to_scene
    log "=== 部署模式结束 ==="
    ;;
  *)
    echo "用法: $0 {install|deploy} [MODPATH]"
    exit 1
    ;;
esac

#!/system/bin/sh

MODPATH="/data/adb/modules/Turbo_Scheduling"
get_soc_dir() {
  local p=$(getprop ro.board.platform)
  local m=$(getprop ro.soc.model)
  case "$p" in
    sun)      echo "8elite" ;;
    pineapple) echo "8gen3" ;;
    *) case "$m" in
         *8750*) echo "8elite" ;;
         *)      echo "8gen3" ;;
       esac ;;
  esac
}
SOC_DIR=$(get_soc_dir)
JSON_DIR="$MODPATH/json"
BACK_DIR="$MODPATH/$SOC_DIR/oplus_json"
LOG_DIR="$MODPATH/log"
LOG_FILE="$LOG_DIR/pkg.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

log "=== 包名匹配开始 ==="
log "模板目录: $BACK_DIR"
log "输出目录: $JSON_DIR"

mkdir -p "$JSON_DIR"

installed_pkgs=$(pm list packages -3 2>&1 | sed 's/package://')
[ -z "$installed_pkgs" ] && { log "错误: 无法获取已安装包列表"; echo "  ! 无法获取已安装应用列表"; exit 1; }

rule_pkgs=""
for json_file in "$BACK_DIR"/*.json; do
  [ -f "$json_file" ] && rule_pkgs="$rule_pkgs $(basename "$json_file" .json)"
done
log "加载规则模板: $(echo "$rule_pkgs" | wc -w) 个"

EXTRA_MAP="\
com.miHoYo.Yuanshen:com.miHoYo.yuanshencb,com.miHoYo.GenshinImpact,com.miHoYo.ys.bilibili \
com.miHoYo.hkrpg:com.HoYoverse.hkrpgoversea \
com.miHoYo.Nap:com.miHoYo.NapCb,com.HoYoverse.Nap \
com.tencent.tmgp.cod:com.garena.game.codm \
com.tencent.tmgp.sgame:com.tencent.tmgp.sgamece,com.levelinfinite.sgameGlobal.midaspay \
com.tencent.mf.uam:com.proximabeta.mf.uamo \
com.pubg.imobile:com.tencent.ig,com.pubg.krmobile"

adapt_json() {
  local src_pkg="$1"
  local dst_pkg="$2"
  local src_json="$BACK_DIR/${src_pkg}.json"
  local dst_json="$JSON_DIR/${dst_pkg}.json"
  [ -f "$src_json" ] && [ ! -f "$dst_json" ] && {
    sed "s/\"package_name\": \"$src_pkg\"/\"package_name\": \"$dst_pkg\"/" "$src_json" > "$dst_json"
    chmod 644 "$dst_json"
    log "适配: $src_pkg → $dst_pkg"
  }
}

pkg_in_list() { echo "$installed_pkgs" | grep -qxF "$1"; }

match_count=0
for entry in $EXTRA_MAP; do
  rule_pkg="${entry%%:*}"
  aliases="${entry#*:}"
  saved_ifs="$IFS"
  IFS=','
  for alias in $aliases; do
    pkg_in_list "$alias" && { adapt_json "$rule_pkg" "$alias"; match_count=$((match_count + 1)); }
  done
  IFS="$saved_ifs"
done

for rule_pkg in $rule_pkgs; do
  if pkg_in_list "$rule_pkg"; then
    dst_file="$JSON_DIR/${rule_pkg}.json"
    if [ -f "$BACK_DIR/${rule_pkg}.json" ] && [ ! -f "$dst_file" ]; then
      cp "$BACK_DIR/${rule_pkg}.json" "$dst_file"
      match_count=$((match_count + 1))
      log "匹配: $rule_pkg"
    fi
  fi
  for pkg in $installed_pkgs; do
    [ -z "$pkg" ] && continue
    case "$pkg" in "${rule_pkg}."*)
      adapt_json "$rule_pkg" "$pkg"; match_count=$((match_count + 1)) ;;
    esac
  done
done

log "匹配完成: 新增 $match_count"
total_json=$(ls "$JSON_DIR"/*.json 2>/dev/null | wc -l)
log "json目录共 $total_json 个配置文件"
if [ "$total_json" -eq 0 ]; then
  echo "  ! 未检测到已安装的受支持游戏"
fi
log "=== 包名匹配结束 ==="

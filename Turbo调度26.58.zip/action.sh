#!/system/bin/sh

MODDIR="${0%/*}"
SCRIPTS_DIR="$MODDIR/scripts"
SCRC_DIR="/data/adb/scrc"
LOG_DIR="$MODDIR/log"
LOG_FILE="$LOG_DIR/action.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

if [ "$1" = "inject" ]; then
  exec sh "$SCRIPTS_DIR/cloud_ctrl.sh" inject
fi

wait_key() {
  timeout=$1
  start_time=$(date +%s)
  while true; do
    current_time=$(date +%s)
    [ $((current_time - start_time)) -ge $timeout ] && { echo "timeout"; return; }
    event=$(getevent -lqc 1 2>/dev/null | {
      while read -r line; do
        case "$line" in
          *KEY_VOLUMEDOWN*DOWN*) echo "down" && break ;;
          *KEY_VOLUMEUP*DOWN*) echo "up" && break ;;
        esac
      done
    })
    [ -n "$event" ] && { echo "$event"; return; }
    usleep 50000
  done
}

restore_backup() {
  BACKUP_DIR="$SCRC_DIR/backup"
  TARGET_DIR="/data/data/com.omarea.vtools/files"

  echo ""
  echo "=== 恢复Scene备份 ==="

  [ "$(id -u)" -ne 0 ] && { echo "! 需要ROOT权限"; log "错误: 非root"; return 1; }
  [ ! -d "$BACKUP_DIR" ] && { echo "! 未找到备份"; log "错误: 备份不存在"; return 1; }

  log "开始恢复Scene配置..."

  chmod -R 777 "$TARGET_DIR" 2>/dev/null
  cp -af "$BACKUP_DIR/." "$TARGET_DIR/" 2>/dev/null
  chown -R system:system "$TARGET_DIR" 2>/dev/null
  find "$TARGET_DIR" -type d -exec chmod 755 {} \; 2>/dev/null
  find "$TARGET_DIR" -type f -exec chmod 777 {} \; 2>/dev/null
  chmod 755 "$TARGET_DIR" 2>/dev/null

  setprop persist.sys.oiface.enable 1
  setprop persist.sys.oplus.gameswitch.enable 1
  start vendor.urcc-hal-aidl 2>/dev/null
  start gameopt_hal_service-1-0 2>/dev/null
  start oiface 2>/dev/null
  start horae 2>/dev/null

  log "Scene配置恢复完成"
  echo "+ 已恢复官方配置"
  echo "=== 完成 ==="
}

uninstall_module() {
  echo ""
  echo "=== 模块卸载 ==="
  log "=== 卸载开始 ==="

  [ "$(id -u)" -ne 0 ] && { echo "! 需要ROOT权限"; log "错误: 非root"; exit 1; }

  if [ -f "$SCRC_DIR/sc_installed" ]; then
    echo "- 还原Scene配置..."
    log "还原Scene配置"
    chmod -R 777 "/data/data/com.omarea.vtools/files" 2>/dev/null
    [ -d "$SCRC_DIR/backup" ] && cp -af "$SCRC_DIR/backup/." "/data/data/com.omarea.vtools/files/" 2>/dev/null
    chown -R system:system "/data/data/com.omarea.vtools/files" 2>/dev/null
    chmod -R 777 "/data/data/com.omarea.vtools/files" 2>/dev/null
    setprop persist.sys.oiface.enable 1
    setprop persist.sys.oplus.gameswitch.enable 1
    start vendor.urcc-hal-aidl 2>/dev/null
    start gameopt_hal_service-1-0 2>/dev/null
    start oiface 2>/dev/null
    start horae 2>/dev/null
  fi

  if [ -f "$SCRC_DIR/rc_installed" ]; then
    echo "- 清理云控数据..."
    log "清理云控数据"
    am force-stop com.oplus.cosa 2>/dev/null
    sleep 1
    pm clear com.oplus.cosa 2>/dev/null
    sleep 2
  fi

  rm -rf "$SCRC_DIR"
  rm -f /data/adb/service.d/.turbo_restore.sh
  log "清理标志文件完成"

  echo "- 删除模块文件..."
  rm -rf "$MODDIR" 2>/dev/null
  log "模块文件删除完成"

  echo "+ 卸载完成，建议重启设备"
  log "=== 卸载完成 ==="
  exit 0
}

echo ""
echo "+----------------------------------------+"
echo "|        Turbo调度 · 操作菜单            |"
echo "+----------------------------------------+"
echo ""
log "=== 操作菜单启动 ==="

if [ -f "$SCRC_DIR/rc_installed" ]; then
  echo "  [音量+] 注入云控配置"
  echo "  [音量-] 下一选项"
  echo ""
  choice=$(wait_key 15)
  case "$choice" in
    "up")
      log "用户选择: 注入云控"
      echo ""
      echo "- 匹配已安装游戏..."
      sh "$SCRIPTS_DIR/pkg_matcher.sh"
      sh "$SCRIPTS_DIR/cloud_ctrl.sh" inject
      echo ""; echo "3秒后退出..."; sleep 3; exit 0 ;;
  esac
fi

echo "  [音量+] 恢复Scene备份配置"
echo "  [音量-] 下一选项"
echo ""
choice=$(wait_key 15)
case "$choice" in
  "up")
    log "用户选择: 恢复备份"
    restore_backup
    echo ""; echo "3秒后退出..."; sleep 3; exit 0 ;;
esac

echo "  [音量+] 卸载模块（恢复备份 + 清理数据）"
echo "  [音量-] 退出"
echo ""
choice=$(wait_key 15)
case "$choice" in
  "up")
    log "用户选择: 卸载模块"
    uninstall_module ;;
  *)
    log "用户选择: 退出"
    echo "已退出"; exit 0 ;;
esac

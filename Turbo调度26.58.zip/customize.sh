#!/system/bin/sh

SKIPUNZIP=0
[ -z "$MODPATH" ] && MODPATH="$1"
[ -z "$LOG_FILE" ] && LOG_FILE="/data/adb/ksu_install.log"

SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

SCRC_DIR="/data/adb/scrc"
SCRIPTS_DIR="$MODPATH/scripts"

ui_print() {
  echo "$1"
  [ -f "/proc/ksu" ] && {
    echo "[$(date "+%m-%d %T")] $1" >> "$LOG_FILE"
    log -p i -t "KSuModule" "$1"
  }
}

get_key() {
  (timeout 3 getevent -qlc 1) 2>/dev/null | grep -E 'KEY_VOLUMEUP.*DOWN|KEY_VOLUMEDOWN.*DOWN' | awk '{print $3}' | head -n1
}

wait_key() {
  while :; do
    key=$(get_key)
    [ -n "$key" ] && echo "$key" && return
    sleep 0.1
  done
}

validate_soc() {
  platform=$(getprop ro.board.platform)
  soc_model=$(getprop ro.soc.model)

  if [ "$platform" = "pineapple" ]; then
    ui_print "+ 骁龙8 Gen3 (pineapple)"
    return 0
  fi

  echo "$soc_model" | grep -qi "8650" && {
    ui_print "+ 骁龙8 Gen3 (SM8650)"
    return 0
  }

  if [ "$platform" = "sun" ]; then
    ui_print "+ 骁龙8 Elite (sun)"
    return 0
  fi

  echo "$soc_model" | grep -qi "8750" && {
    ui_print "+ 骁龙8 Elite (SM8750)"
    return 0
  }

  ui_print "! 仅支持骁龙8 Gen3 / 8 Elite"
  ui_print "  Platform: ${platform:-未知}"
  ui_print "  SoC: ${soc_model:-未知}"
  return 1
}

extract_app() {
  if [ -f "/proc/zipalign" ]; then
    unzip -oj "$ZIPFILE" "KsuWebUI.apk" -d "$MODPATH" >/dev/null 2>&1 && return 0
  fi
  [ -n "$MAGISK_MODULE_ZIP" ] && {
    unzip -oj "$MAGISK_MODULE_ZIP" "KsuWebUI.apk" -d "$MODPATH" >/dev/null 2>&1 && return 0
  }
  zip_path=$(grep '\.zip' /proc/self/mountinfo 2>/dev/null | tail -n1 | awk '{print $5}')
  [ -f "$zip_path" ] && {
    unzip -oj "$zip_path" "KsuWebUI.apk" -d "$MODPATH" >/dev/null 2>&1 && return 0
  }
  ui_print "! 无法定位模块 ZIP"
  return 1
}

install_webui() {
  ui_print "- WebUI 处理中..."
  [ -f "$MODPATH/KsuWebUI.apk" ] || { extract_app || { ui_print "  ! WebUI 跳过"; return 1; }; }

  if [ -f "/data/adb/magisk.db" ] || ls /data/adb/magisk/*magisk* >/dev/null 2>&1; then
    pm install -g -r "$MODPATH/KsuWebUI.apk" >/dev/null 2>&1 && ui_print "  + WebUI 已安装" || ui_print "  ! 请手动安装 APK"
  else
    ui_print "  + KernelSU 环境，无需操作"
  fi
  rm -f "$MODPATH/KsuWebUI.apk"
}

update_description() {
  local desc
  if [ -f "$SCRC_DIR/rc_installed" ] && [ -f "$SCRC_DIR/sc_installed" ]; then
    desc="云控注入 + 二改调度($(cat "$SCRC_DIR/config_type" 2>/dev/null))"
  elif [ -f "$SCRC_DIR/rc_installed" ]; then
    desc="云控注入"
  elif [ -f "$SCRC_DIR/sc_installed" ]; then
    desc="二改调度($(cat "$SCRC_DIR/config_type" 2>/dev/null))"
  else
    desc="无任何功能，建议卸载"
  fi
  sed -i "s/^description=.*/description=$desc/" "$MODPATH/module.prop"
}

clean_after_install() {
  if [ -f "$SCRC_DIR/sc_installed" ]; then
    for soc in 8gen3 8elite; do
      rm -rf "$MODPATH/$soc/generic_config" 2>/dev/null
      rm -rf "$MODPATH/$soc/oplus_config" 2>/dev/null
    done
  fi
  rm -f "$MODPATH/auto.sh"
}

set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0644
  [ -f "$MODPATH/service.sh" ]      && set_perm "$MODPATH/service.sh" 0 0 0755
  [ -f "$MODPATH/post-fs-data.sh" ] && set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
  [ -f "$MODPATH/action.sh" ]       && set_perm "$MODPATH/action.sh" 0 0 0755
  [ -d "$MODPATH/scripts" ] && {
    set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
  }
  [ -d "$MODPATH/tool" ] && {
    chmod 777 "$MODPATH/tool/sqlite3" 2>/dev/null
    chmod 777 "$MODPATH/tool/jq" 2>/dev/null
    chmod 777 "$MODPATH/tool/yt" 2>/dev/null
    chmod 777 "$MODPATH/tool/inotify" 2>/dev/null
  }
}

ui_print "+----------------------------------------+"
ui_print "|     Turbo-Scheduling · 安装启动        |"
ui_print "+----------------------------------------+"

timeout 0.5 getevent >/dev/null 2>/dev/null
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "! 刷入须知"
ui_print "  . 调度默认 Scene9 正版"
ui_print "    Scene9 以下版本请尽快升级"
ui_print "    破解版请使用正版"
ui_print "  . 需正版 Scene9 开启 HP 调度"
ui_print "  . 二改调度与云控注入可独立选择"
ui_print "  . 通用版不可搭配云控注入"
ui_print "  . oplus版仅日用调度，可搭配云控"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  [音量+] 同意并继续"
ui_print "  [音量-] 取消"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"

key=$(wait_key)
[ "$key" = "KEY_VOLUMEDOWN" ] && exit 1

validate_soc || {
  ui_print "! 设备验证未通过，终止安装"
  exit 1
}

ui_print "- 2秒后继续..."
sleep 2

ui_print ""
ui_print "━━━ 二改调度 & 云控配置 ━━━"
ui_print ""
sh "$SCRIPTS_DIR/scene_config.sh" install "$MODPATH"

ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  是否查看 Turbo 的酷安主页？"
ui_print "  [音量+] 打开  [音量-] 跳过"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"

key=$(wait_key)
[ "$key" = "KEY_VOLUMEUP" ] && {
  am start -a android.intent.action.VIEW -d "https://www.coolapk.com/u/36667900" >/dev/null 2>&1 &
  ui_print "  + 已打开"
} || ui_print "  - 已跳过"

ui_print "- 2秒后继续..."
sleep 2

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  是否加入 Turbo 交流群？"
ui_print "  [音量+] 加入QQ群  [音量-] 跳过"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"

key=$(wait_key)
[ "$key" = "KEY_VOLUMEUP" ] && {
  am start -a android.intent.action.VIEW -d "https://qun.qq.com/universal-share/share?ac=1&authKey=fbBTMojWZqU6dl9ZgzxJuVMbDpz7i5vglP525ADa9G0QD68Y4msUVZeQ2VIpUkjY&busi_data=eyJncm91cENvZGUiOiI3NjQ1NzAyOTciLCJ0b2tlbiI6ImZWQ3ZRdUlQd2pWQjRyTHJQYk5qMFZnN3NJc09FRXBSYjUxQTZCY0Nac25idHJjMUpheWZFRXBHbHBTOWhqd2siLCJ1aW4iOiIzOTgzMjE1MTQ1In0%3D&data=iI8p004GAXEMHzYscGhAcch1NckHBkb1T0_eWZWK6YCvyCaJw2cZNDXRZ1N146nKYrcaPYfstgLIZEvBMGwC4g&svctype=4&tempid=h5_group_info" >/dev/null 2>&1 &
  ui_print "  + 已打开"
} || ui_print "  - 已跳过"

ui_print ""

install_webui

clean_after_install

update_description

set_permissions

ui_print ""
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  + Turbo-Scheduling · 安装完成"
ui_print "    好了，重启吧"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━"

#!/system/bin/sh

MODDIR="${0%/*}"
SCRIPTS_DIR="$MODDIR/scripts"
SCRC_DIR="/data/adb/scrc"
VT_FILES="/data/data/com.omarea.vtools/files"
LOG_DIR="$MODDIR/log"
LOG_FILE="$LOG_DIR/boot.log"

mkdir -p "$LOG_DIR"

log() {
  echo "[$(date '+%m-%d %T')] $1" >> "$LOG_FILE"
}

stop_official() {
  log "停止官方调度服务"
  stop vendor.urcc-hal-aidl 2>/dev/null
  stop gameopt_hal_service-1-0 2>/dev/null
  stop vendor.oplus.ormsHalService-aidl-default 2>/dev/null
  setprop persist.sys.oiface.enable 0
  stop oiface 2>/dev/null
}

start_official() {
  log "恢复官方调度服务"
  setprop persist.sys.oiface.enable 1
  setprop persist.sys.oplus.gameswitch.enable 1
  setprop persist.sys.horae.enable 1
  start oiface 2>/dev/null
  start horae 2>/dev/null
  start gameopt_hal_service-1-0 2>/dev/null
  start vendor.urcc-hal-aidl 2>/dev/null
}

log "========================================="
log "Turbo调度 开机服务启动"

if [ -f "$SCRC_DIR/sc_installed" ]; then
  config_type=$(cat "$SCRC_DIR/config_type" 2>/dev/null)

  log "[Scene] 等待45秒... (类型: $config_type)"
  sleep 45
  sh "$SCRIPTS_DIR/scene_config.sh" deploy

  sleep 30

  if [ "$config_type" = "generic" ]; then
    log "[Scene] 通用版: 停止官方调度服务"
    stop_official
  elif [ "$config_type" = "oplus" ]; then
    log "[Scene] oplus版: 保持官方调度服务"
    start_official
  fi

  log "[Scene] 加固 executor 权限"
  sed -i 's/chmod 755 "$script_path"/chmod 777 "$script_path"/g' "$VT_FILES/kr-script/executor.sh" 2>/dev/null
  chmod 555 "$VT_FILES/kr-script/executor.sh" 2>/dev/null
  chmod 777 "$VT_FILES/kr-script/cache" 2>/dev/null
  find "$VT_FILES/kr-script/cache" -type f -exec chmod 777 {} + 2>/dev/null
  find "$VT_FILES/kr-script/cache" -type d -exec chmod 777 {} + 2>/dev/null

  log "[Scene] 初始化完成"
fi

if [ -f "$SCRC_DIR/rc_installed" ]; then
  log "[云控] 后台服务启动"

  {
    echo "[$(date '+%m-%d %T')] 云控服务启动"
    echo "[$(date '+%m-%d %T')] 确保官方调度服务运行..."
    setprop persist.sys.oiface.enable 1
    setprop persist.sys.oplus.gameswitch.enable 1
    start oiface 2>/dev/null
    start gameopt_hal_service-1-0 2>/dev/null
    start vendor.urcc-hal-aidl 2>/dev/null

    sleep 60
    echo "[$(date '+%m-%d %T')] 执行包名匹配..."
    sh "$SCRIPTS_DIR/pkg_matcher.sh"

    MAX_WAIT=300
    WAIT_INTERVAL=5
    elapsed=0

    while [ $elapsed -lt $MAX_WAIT ]; do
      DB=$(find /data/data/com.oplus.cosa/databases /data/user_de/0/com.oplus.cosa/databases -name "db_game_database" -type f 2>/dev/null | head -n1)
      if [ -n "$DB" ]; then
        echo "[$(date '+%m-%d %T')] 数据库就绪: $DB"
        sleep 10
        echo "[$(date '+%m-%d %T')] 开始注入..."
        sh "$SCRIPTS_DIR/cloud_ctrl.sh" inject
        echo "[$(date '+%m-%d %T')] 调校调速器..."
        sh "$SCRIPTS_DIR/gov_tuner.sh"
        echo "[$(date '+%m-%d %T')] 启动 inotify 守护..."
        exec "$MODDIR/tool/inotify" 2>/dev/null
      fi
      sleep $WAIT_INTERVAL
      elapsed=$((elapsed + WAIT_INTERVAL))
      echo "[$(date '+%m-%d %T')] 等待数据库... ${elapsed}s"
    done

    echo "[$(date '+%m-%d %T')] 错误: 超时未找到数据库"
  } >> "$LOG_FILE" 2>&1 &
fi

log "========================================="

#!/system/bin/sh

MODDIR="${0%/*}"
SCRC_DIR="/data/adb/scrc"
BACKUP_DIR="$SCRC_DIR/backup"
SERVICE_DIR="/data/adb/service.d"
DAEMON_FILE="$SERVICE_DIR/.turbo_restore.sh"
TARGET_DIR="/data/data/com.omarea.vtools/files"

if [ -f "$SCRC_DIR/sc_installed" ]; then
  file_count=$(find "$BACKUP_DIR" -maxdepth 1 -type f 2>/dev/null | wc -l)
  if [ "$file_count" -eq 0 ]; then
    mkdir -p "$BACKUP_DIR"
    cp -af "${TARGET_DIR}/." "$BACKUP_DIR/" 2>/dev/null
  fi

  if [ ! -f "$DAEMON_FILE" ]; then
    cat > "$DAEMON_FILE" << 'EOF'
#!/system/bin/sh
if [ -d "/data/adb/modules/scrc" ] || [ -d "/data/adb/modules/Turbo_Scheduling" ]; then
  exit 0
fi

while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done

TARGET_DIR="/data/data/com.omarea.vtools/files"
BACKUP_DIR="/data/adb/scrc/backup"
SELF="/data/adb/service.d/.turbo_restore.sh"

WAIT_TIME=0
while [ ! -d "$TARGET_DIR" ] && [ $WAIT_TIME -lt 60 ]; do
  sleep 2; WAIT_TIME=$((WAIT_TIME + 2))
done

sleep 10
mkdir -p "$TARGET_DIR"
chmod -R 777 "$TARGET_DIR" 2>/dev/null
[ -d "$BACKUP_DIR" ] && cp -af "$BACKUP_DIR/." "$TARGET_DIR/" 2>/dev/null
chown -R system:system "$TARGET_DIR" 2>/dev/null
chmod -R 777 "$TARGET_DIR" 2>/dev/null

if [ -d "/data/adb/scrc" ]; then
  am force-stop com.oplus.cosa 2>/dev/null
  sleep 1
  pm clear com.oplus.cosa 2>/dev/null
  sleep 2
  rm -rf /data/adb/scrc
fi

setprop persist.sys.oiface.enable 1
setprop persist.sys.oplus.gameswitch.enable 1
start vendor.urcc-hal-aidl 2>/dev/null
start gameopt_hal_service-1-0 2>/dev/null
start oiface 2>/dev/null
start horae 2>/dev/null

rm -rf "$BACKUP_DIR"
rm -f "$SELF"
exit 0
EOF
    chmod 755 "$DAEMON_FILE"
    chown root:root "$DAEMON_FILE"
  fi
fi

chmod 755 "$0"
chown root:root "$0"

[ -f "${MODDIR}/disable" ] && exit 0

#!/system/bin/sh

MODPATH="${0%/*/*}"
LOG_DIR="$MODPATH/log"
LOG_FILE="$LOG_DIR/pkg.log"

mkdir -p "$LOG_DIR"
. "${0%/*}/common.sh"

SOC_DIR=$(get_soc_dir)
CCCF_DIR="$MODPATH/cccf"
BACK_DIR="$CCCF_DIR"

log "=== 包名匹配开始 ==="
log "模板目录: $BACK_DIR"
log "输出目录: $CCCF_DIR"

mkdir -p "$CCCF_DIR"

installed_pkgs=$(pm list packages -3 2>/dev/null | grep '^package:' | sed 's/^package://')
[ -z "$installed_pkgs" ] && { log "错误: 无法获取已安装包列表"; echo "  ! 无法获取已安装应用列表"; exit 1; }

rule_pkgs=""
for json_file in "$BACK_DIR"/*.json "$BACK_DIR"/*.enc; do
  # 纯 shell 剥后缀: sed 的 \| 交替是 GNU 扩展, Android bionic regex 不支持
  [ -f "$json_file" ] && { b=$(basename "$json_file"); rule_pkgs="$rule_pkgs ${b%.*}"; }
done
if [ -z "$rule_pkgs" ]; then
  log "错误: 云控模板缺失 ($BACK_DIR), 跳过匹配, 请重新安装模块"
  echo "  ! 云控模板缺失, 请重新安装模块"
  exit 1
fi
# 按长度降序, 优先最长模板 (避免短前缀误配)
rule_pkgs_sorted=$(for t in $rule_pkgs; do echo "$t"; done | awk '{print length, $0}' | sort -rn | sed 's/^[0-9]* //')
log "加载规则模板: $(echo "$rule_pkgs" | wc -w) 个"

# 白名单兜底 (变体匹配未命中时生效); 来源: 9400云控修改 EXTRA_MAP, 用户可编辑 scripts/whitelist.conf
WL_CONF="${0%/*}/whitelist.conf"
if [ -f "$WL_CONF" ]; then
  WHITELIST_MAP=$(grep -v '^#' "$WL_CONF" 2>/dev/null | grep -v '^[[:space:]]*$')
fi
# 内置兜底 (whitelist.conf 缺失时使用): 与 9400云控修改 auto.sh EXTRA_MAP 保持一致
[ -z "$WHITELIST_MAP" ] && WHITELIST_MAP="\
com.miHoYo.yuanshencb:com.miHoYo.Yuanshen \
com.miHoYo.GenshinImpact:com.miHoYo.Yuanshen \
com.miHoYo.ys.bilibili:com.miHoYo.Yuanshen \
com.HoYoverse.hkrpgoversea:com.miHoYo.hkrpg \
com.miHoYo.NapCb:com.miHoYo.Nap \
com.HoYoverse.Nap:com.miHoYo.Nap \
com.garena.game.codm:com.tencent.tmgp.cod \
com.tencent.tmgp.sgamece:com.tencent.tmgp.sgame \
com.levelinfinite.sgameGlobal.midaspay:com.tencent.tmgp.sgame \
com.proximabeta.mf.uamo:com.tencent.mf.uam \
com.tencent.ig:com.pubg.imobile \
com.pubg.krmobile:com.pubg.imobile \
com.vng.pubgmobile:com.pubg.imobile \
com.rekoo.pubgm:com.pubg.imobile \
com.tencent.tmgp.yongyong.mrzh:com.netease.mrzh \
com.garena.game.df:com.tencent.tmgp.dfm \
com.tencent.tmgp.bairimeng.dmmdzz:com.bairimeng.dmmdzz"

adapt_json() {
  local src_pkg="$1"
  local dst_pkg="$2"
  local src_json="$BACK_DIR/${src_pkg}.json"
  local dst_json="$CCCF_DIR/${dst_pkg}.json"
  local official_json="$CCCF_DIR/${src_pkg}.json"
  [ -f "$src_json" ] || return 1
  local copied=1
  if [ ! -f "$official_json" ]; then
    cp "$src_json" "$official_json" && chmod 777 "$official_json" && { log "官服: $src_pkg"; copied=0; }
  fi
  if [ ! -f "$dst_json" ]; then
    sed "s/\"package_name\": \"$src_pkg\"/\"package_name\": \"$dst_pkg\"/" "$src_json" > "$dst_json" \
      && chmod 777 "$dst_json" && { log "适配: $src_pkg → $dst_pkg"; copied=0; }
  fi
  return $copied   # 0=实际写入 (调用方据此计数)
}

pkg_in_list() { echo "$installed_pkgs" | grep -qxF "$1"; }

match_count=0

# ── 1. 官服精确 + 前缀变体匹配 ──
for rule_pkg in $rule_pkgs_sorted; do
  if pkg_in_list "$rule_pkg"; then
    if [ -f "$BACK_DIR/${rule_pkg}.json" ]; then
      dst_file="$CCCF_DIR/${rule_pkg}.json"
      if [ ! -f "$dst_file" ]; then
        cp "$BACK_DIR/${rule_pkg}.json" "$dst_file"
        chmod 777 "$dst_file"
        match_count=$((match_count + 1))
        log "匹配: $rule_pkg"
      fi
    elif [ -f "$BACK_DIR/${rule_pkg}.enc" ]; then
      dst_file="$CCCF_DIR/${rule_pkg}.enc"
      if [ ! -f "$dst_file" ]; then
        cp "$BACK_DIR/${rule_pkg}.enc" "$dst_file"
        chmod 777 "$dst_file"
        match_count=$((match_count + 1))
        log "匹配(enc): $rule_pkg"
      fi
    fi
  fi
  # 变体匹配: 仅 json 模板 (enc 无法改写包名)
  [ -f "$BACK_DIR/${rule_pkg}.json" ] || continue
  for pkg in $installed_pkgs; do
    [ -z "$pkg" ] && continue
    [ "$pkg" = "$rule_pkg" ] && continue
    case "$pkg" in
      "${rule_pkg}"*)
        if adapt_json "$rule_pkg" "$pkg"; then
          match_count=$((match_count + 1))
          log "变体匹配: $rule_pkg → $pkg"
        fi ;;
    esac
  done
done

# ── 2. 白名单兜底 ──
for entry in $WHITELIST_MAP; do
  channel="${entry%%:*}"
  official="${entry#*:}"
  pkg_in_list "$channel" && [ ! -f "$CCCF_DIR/${channel}.json" ] && {
    if adapt_json "$official" "$channel"; then
      match_count=$((match_count + 1))
      log "白名单兜底: $official → $channel"
    fi
  }
done

log "匹配完成: 新增 $match_count"
total_json=$(ls "$CCCF_DIR"/*.json 2>/dev/null | wc -l)
log "cccf目录共 $total_json 个配置文件"
if [ "$total_json" -eq 0 ]; then
  echo "  ! 未检测到已安装的受支持游戏"
fi
log "=== 包名匹配结束 ==="
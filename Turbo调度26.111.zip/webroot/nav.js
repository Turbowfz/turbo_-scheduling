/* ── Tab 导航 (物理弹簧指示器) ── */
const TAB_NAMES = ['status','config','cloud','about'];
let _curTab = 0;
let _tabbarDragging = false;

/* ── 震动: 已按需求关闭 (原先 navigator.vibrate 失效时会落 root 兜底,
   而 ksu 通道串行 —— 拖动跨档连震会让滑块卡顿)。保留入口与调用点, 需要时改回即可 ── */
window.haptic = function() {};
function tapVibrate() { haptic(); }

/* 状态刷新避开滑块动画: 刷新要跑 root 命令 (ksu 通道串行), 动画期间会卡住滑块 */
function refreshWhenIdle(fn, delay) {
  setTimeout(function tick() {
    if (window._tabbarAnimating) { setTimeout(tick, 120); return; }
    try { fn(); } catch (_) {}
  }, delay || 0);
}

window.switchTab = function(name) {
  const idx = TAB_NAMES.indexOf(name);
  if (idx < 0) return;
  _curTab = idx;

  /* 指示器优先起飞: 先于页面 DOM 操作启动弹簧, 让 rAF 尽早注册 ——
     页面切换的 DOM 操作 (遍历所有 page/tab 改 class + 卡片入场动画) 若排在前面,
     会把滑块的起步挤到后面几帧, 表现为"点按后稍有延迟才动" */
  if (window._aimIndicator) window._aimIndicator(name);

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  const page = document.getElementById('page-' + name);
  const tab  = document.getElementById('tab-'  + name);
  if (page) page.classList.add('active');
  if (tab)  tab.classList.add('active');
  if (page) {
    page.querySelectorAll('.card:not(.in), .card-anim:not(.in)').forEach((c, i) => {
      c.style.setProperty('--del', (i * 28) + 'ms');
      c.classList.add('in');
    });
  }
  /* 状态刷新延后到滑块动画结束: 刷新要跑 root 命令, 动画期间会把滑块卡住 */
  if (name === 'status') refreshWhenIdle(refreshStatus, 160);
};

/* ══════ 指示器: 统一弹簧驱动 (位置 + 缩放) ══════
   坐标参照系: 所有位置值都相对 tabbar 的 padding box (与 ind.style.left 一致) ——
   getBoundingClientRect 返回的是 border box 坐标, 必须补上 tabbar.clientLeft 才能对齐。
   位置/宽度只在初始化时写一次, 之后所有移动都走 transform ——
   避免 CSS 过渡与 JS 动画互相覆盖导致的"闪现回原位"bug。
   缩放由独立弹簧驱动, 放大/缩小都带非线性回弹 ——
   按住滑块的瞬间即开始放大, 位置落定后才缩回。
   移动态 (拖拽 / 甩动 / 点击切页) 全程保持放大。
   点击切页时若指示器正在飞行:
     · 同方向 → 直接重瞄新目标
     · 反方向 → 速度衰减(撞墙感)后由弹簧拉回新目标
   飞行期间缩放保持不变, 位置到位后才缩回 —— 符合"先到, 后缩"的要求。

   ⚠ 初始化时机很关键: tabbar 入场动画 (tabbar-in) 期间 tabbar 有 scale(.92),
     getBoundingClientRect 返回的是变换后的坐标 —— 宽度会被读成布局值的 92%,
     动画结束后 tab 恢复原宽, 指示器却停在缩小版尺寸 → 永久对不齐。
     因此 init 必须等到动画结束 (animationend) 或超时兜底后再执行。 */
(function initTabbarDrag() {
  const tabbar = document.getElementById('tabbar');
  const ind    = document.getElementById('tab-indicator');
  if (!tabbar || !ind) return;

  /* 物理常量 */
  const PH = {
    DRAG_K: 0.35,           /* 拖动追手系数 (每帧) */
    K: 100,                 /* 位置弹簧刚度 */
    C: 12,                  /* 位置阻尼 (ζ≈0.6 → 到位一次轻回弹, 不来回荡) */
    SCALE_K: 200,           /* 缩放弹簧刚度 */
    SCALE_C: 18,            /* 缩放阻尼 (ζ≈0.64 → 放大/缩小都带一点回弹) */
    EDGE_K_MUL: 3,          /* 冲出栏端后的刚度倍率 (缓冲减速) */
    EDGE_BOUNCE: 0.3,       /* 顶出缓冲区的反弹系数 */
    MAX_OVER: 16,           /* 最大越出像素 */
    SETTLE_V: 25,           /* 位置落定速度阈值 px/s */
    SETTLE_X: 0.5,          /* 位置落定距离阈值 px */
    SCALE_SETTLE_V: 0.03,   /* 缩放落定速度阈值 /s */
    SCALE_SETTLE_X: 0.003,  /* 缩放落定距离阈值 */
    GRAB_SCALE: 1.28,       /* 抓取/移动态缩放 */
    REVERSE_DAMP: 0.4,      /* 反向点击时的"撞墙"速度衰减 */
  };

  const IND = {
    mode: 'idle',           /* idle | drag | flight */
    pos: 0, vel: 0,         /* 相对 baseLeft 的偏移 + 速度 */
    scale: 1, scaleVel: 0,
    targetPos: 0, targetScale: 1,
    minPos: 0, maxPos: 0,
    baseLeft: 0, baseWid: 0,
    posSettled: true,       /* 位置是否已落定 (用于"先到, 后缩") */
  };

  let visNames = [], visRects = [];
  let tbLeft = 0;
  let startX = 0, startY = 0;
  let dragging = false, intentDecided = false;
  let lastBest = 0;
  let raf = 0, lastFrame = 0;
  let prevT = 0, prevX = 0, lastT = 0, lastX = 0;   /* 速度采样: 倒数两次 move */
  let _suppressClick = false;   /* 拖动/飞行刚结束: 忽略紧随的 click (鼠标拖拽会额外触发一次) */

  /* ── 布局缓存 (所有 rect 都相对 tabbar 的 padding box, 单位 px)
     坐标系说明:
       - 绝对定位子元素 (.tab-indicator) 的 left 是相对 tabbar 的 padding box 计算的
       - getBoundingClientRect 返回 border box 坐标, 需要 + clientLeft 才能换到 padding box
       - 这样 visRects[i].left 与 ind.style.left 就是同一参照系, 不会偏 1px 边框

     ⚠ 调用时机约束: getBoundingClientRect 返回的是**变换后**的坐标。
       tabbar 有 transform (入场动画 scale(.92) / translateY) 时, 读到的宽度是被缩小的,
       不能作为布局值写入 ind.style.width。本函数必须在 tabbar 无 transform 时调用:
         · _initIndicator 由 animationend 或 800ms 兜底触发 —— 动画已结束
         · resize 触发时 tabbar 无动画
         · gestureStart 首次兜底时 tabbar 无动画 */
  function cacheRects() {
    visNames = []; visRects = [];
    tbLeft = tabbar.getBoundingClientRect().left + tabbar.clientLeft;
    for (const n of TAB_NAMES) {
      const el = document.getElementById('tab-' + n);
      if (!el) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 1) continue;
      visNames.push(n);
      visRects.push({ left: r.left - tbLeft, width: r.width });
    }
    if (visRects.length) {
      IND.baseLeft = visRects[0].left;
      IND.baseWid  = visRects[0].width;
      IND.minPos   = 0;
      IND.maxPos   = visRects[visRects.length - 1].left - IND.baseLeft;
    }
  }

  /* 相对 tabbar 的 X → 最近的档位 index */
  function nearestIdx(x) {
    let best = 0, bd = Infinity;
    for (let i = 0; i < visRects.length; i++) {
      const d = Math.abs(x - (visRects[i].left + visRects[i].width / 2));
      if (d < bd) { bd = d; best = i; }
    }
    return best;
  }

  /* 手指 X (屏幕坐标) → 指示器相对 baseLeft 的偏移 (连续插值) */
  function offsetForX(x) {
    const n = visRects.length;
    if (!n) return null;
    const lastR = visRects[n - 1];
    const cx = Math.max(0, Math.min(lastR.left + lastR.width, x - tbLeft));

    let best = lastBest;
    for (let i = 0; i < n; i++) {
      const r = visRects[i];
      if (cx >= r.left && cx <= r.left + r.width) { best = i; break; }
    }
    const cur = visRects[best];
    if (!cur) return null;
    const mid = cur.left + cur.width / 2;
    let t = 0;
    if (cx < mid && best > 0) {
      const pm = visRects[best - 1].left + visRects[best - 1].width / 2;
      if (pm !== mid) t = Math.max(-1, (cx - mid) / (mid - pm));
    } else if (cx > mid && best < n - 1) {
      const nm = visRects[best + 1].left + visRects[best + 1].width / 2;
      if (nm !== mid) t = Math.min(1, (cx - mid) / (nm - mid));
    }
    const tgtIdx = t < 0 ? best - 1 : best + 1;
    const tgt = (t !== 0 && visRects[tgtIdx]) ? visRects[tgtIdx] : null;
    const at = Math.abs(t);
    const left = tgt ? cur.left + (tgt.left - cur.left) * at : cur.left;
    return { pos: left - IND.baseLeft, best };
  }

  function render() {
    ind.style.transform = 'translateX(' + IND.pos + 'px) scale(' + IND.scale + ')';
  }

  /* ── 动画循环 ── */
  function startLoop() {
    window._tabbarAnimating = true;
    if (!raf) { lastFrame = 0; raf = requestAnimationFrame(loop); }
  }
  function stopLoop() {
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    window._tabbarAnimating = false;
  }

  function stepPos(dt) {
    let t = IND.targetPos, k = PH.K;
    if (IND.pos > IND.maxPos)     { t = IND.maxPos; k = PH.K * PH.EDGE_K_MUL; }
    else if (IND.pos < IND.minPos) { t = IND.minPos; k = PH.K * PH.EDGE_K_MUL; }
    const a = k * (t - IND.pos) - PH.C * IND.vel;
    IND.vel += a * dt;
    IND.pos += IND.vel * dt;
    /* 积分后二次钳制: 高速帧一步可能跨过缓冲区, 不钳会飞出栏外 */
    if (IND.pos > IND.maxPos + PH.MAX_OVER) { IND.pos = IND.maxPos + PH.MAX_OVER; IND.vel *= -PH.EDGE_BOUNCE; }
    if (IND.pos < IND.minPos - PH.MAX_OVER) { IND.pos = IND.minPos - PH.MAX_OVER; IND.vel *= -PH.EDGE_BOUNCE; }
  }
  function stepScale(dt) {
    const a = PH.SCALE_K * (IND.targetScale - IND.scale) - PH.SCALE_C * IND.scaleVel;
    IND.scaleVel += a * dt;
    IND.scale += IND.scaleVel * dt;
  }

  function loop(now) {
    raf = 0;
    if (!lastFrame) lastFrame = now;
    let dt = (now - lastFrame) / 1000;
    lastFrame = now;
    if (dt > 0.05) dt = 0.05;      /* 帧间隔过长时钳制, 防积分爆炸 */
    if (dt <= 0) dt = 0.016;

    let active = false;

    if (IND.mode === 'drag') {
      /* 拖拽期: 位置用阻尼追手 (轻微滞后黏滑), 缩放用弹簧 (放大带过冲) */
      IND.pos += (IND.targetPos - IND.pos) * PH.DRAG_K;
      stepScale(dt);
      active = true;
    } else if (IND.mode === 'flight') {
      stepPos(dt);
      stepScale(dt);

      /* 位置到位 → 立即切页 + 解除缩放目标 (符合"先到指定位置, 再缩小") */
      if (!IND.posSettled &&
          Math.abs(IND.vel) < PH.SETTLE_V &&
          Math.abs(IND.pos - IND.targetPos) < PH.SETTLE_X) {
        IND.posSettled = true;
        IND.pos = IND.targetPos;
        IND.vel = 0;
        IND.targetScale = 1;   /* 位置落定 → 触发缩放弹簧回弹到 1 */
        /* 按实际停下的位置取档 */
        const landIdx = nearestIdx(IND.pos + IND.baseLeft + IND.baseWid / 2);
        const landTab = visNames[landIdx];
        if (landTab && landTab !== TAB_NAMES[_curTab]) switchTab(landTab);
      }

      const scaleDone =
        Math.abs(IND.scaleVel) < PH.SCALE_SETTLE_V &&
        Math.abs(IND.scale - IND.targetScale) < PH.SCALE_SETTLE_X;

      /* 位置与缩放都落定 → 收尾复位 */
      if (IND.posSettled && scaleDone) {
        IND.pos = IND.targetPos;
        IND.scale = IND.targetScale;
        IND.vel = 0; IND.scaleVel = 0;
        IND.mode = 'idle';
        ind.classList.remove('grabbed');
        render();
        stopLoop();
        return;
      }
      active = true;
    }

    render();

    if (active) {
      raf = requestAnimationFrame(loop);
    } else {
      window._tabbarAnimating = false;
      IND.mode = 'idle';
    }
  }

  /* ── 点击/程序切页时, 指示器瞄准新目标 ──
     优先级: 用户点击 > 进行中的飞行。
     所有会改变位置的分支都把 targetScale 设为 GRAB_SCALE ——
     保证滑块"移动时始终放大, 停止后才缩回"。
     本函数不再调 cacheRects(): rects 由 init / resize 维护, 避免点按时
     getBoundingClientRect() 触发强制同步布局造成的起步延迟。 */
  function aimAt(tabName) {
    if (!visRects.length) cacheRects();   /* 首帧保护: init 尚未跑过时补一次 */
    const idx = visNames.indexOf(tabName);
    if (idx < 0) return;
    const targetPos = visRects[idx].left - IND.baseLeft;

    /* 已在目标附近且速度不高: 无需动作 (避免 loop 内 switchTab → aimAt 递归触发) */
    if (Math.abs(IND.pos - targetPos) < 0.5 && Math.abs(IND.vel) < 30) return;

    if (IND.mode === 'flight' && Math.abs(IND.vel) > 30) {
      const movingRight = IND.vel > 0;
      const targetRight = targetPos > IND.pos;
      if (movingRight !== targetRight) {
        /* 反向点击: 撞墙回弹 —— 立即卸掉大部分速度, 弹簧自然拉回 */
        IND.vel *= PH.REVERSE_DAMP;
      }
      IND.targetPos = targetPos;
      IND.posSettled = false;
      IND.targetScale = PH.GRAB_SCALE;   /* 移动中保持放大 */
    } else if (IND.mode === 'drag') {
      /* 拖拽中程序切页: 只改目标, 缩放保持抓取态 */
      IND.targetPos = targetPos;
      IND.targetScale = PH.GRAB_SCALE;
    } else {
      /* idle (或飞行末段速度已衰减小) → 重新起飞: 位置零初速起步, 缩放弹到抓取态 */
      IND.mode = 'flight';
      IND.posSettled = false;
      IND.targetPos = targetPos;
      IND.targetScale = PH.GRAB_SCALE;
      startLoop();
    }
  }
  window._aimIndicator = aimAt;

  /* ── 手势 ── */
  function gestureStart(tx, ty, ts) {
    startX = tx; startY = ty;
    if (!visRects.length) cacheRects();
    /* 每次手势开始重算 tbLeft: tabbar 此时必无 transform (入场动画早已结束),
       getBoundingClientRect + clientLeft 得到准确的 padding box 左边缘屏幕坐标 */
    tbLeft = tabbar.getBoundingClientRect().left + tabbar.clientLeft;
    lastBest = Math.max(0, visNames.indexOf(TAB_NAMES[_curTab]));
    dragging = false; intentDecided = false;
    prevT = lastT = ts || 0; prevX = lastX = tx;

    const ir = ind.getBoundingClientRect();
    const onSlider = tx >= ir.left && tx <= ir.right && ty >= ir.top && ty <= ir.bottom;
    /* 按住滑块 或 飞行中任意位置按住: 截停当前运动, 转入抓取 */
    if (onSlider || IND.mode === 'flight') {
      stopLoop();
      IND.mode = 'drag';
      IND.targetPos = IND.pos;                 /* 位置保持不动, 等手指拖动 */
      IND.targetScale = PH.GRAB_SCALE;         /* 缩放目标立刻切到抓取态 */
      IND.posSettled = false;
      ind.classList.add('grabbed');
      /* 关键: 立刻启动 loop —— 缩放弹簧从当前值弹向 GRAB_SCALE (带过冲回弹) */
      startLoop();
    }
  }

  function gestureMove(cx, cy, ts) {
    const dx = cx - startX;
    const dy = cy - startY;
    if (!intentDecided) {
      if (Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
      intentDecided = true;
      if (Math.abs(dy) > Math.abs(dx) * 1.2) return;   /* 纵向, 放弃 */
      dragging = true; _tabbarDragging = true; IND.mode = 'drag';
      IND.targetScale = PH.GRAB_SCALE;
      ind.classList.add('grabbed');
      haptic(10);
    }
    if (!dragging) return;

    prevT = lastT; prevX = lastX;
    lastT = ts || 0; lastX = cx;

    const o = offsetForX(cx);
    if (!o) return;
    IND.targetPos = o.pos;
    if (o.best !== lastBest) { lastBest = o.best; haptic(6); }
    startLoop();
  }

  /* 释放入弹簧: 初速直接进速度, 目标每帧跟随最近档 (在 loop 里更新) */
  function beginFlight(v) {
    IND.mode = 'flight';
    IND.vel = v;
    IND.posSettled = false;
    IND.targetScale = PH.GRAB_SCALE;   /* 飞行期间保持放大, 到位后再缩回 */
    const idx = nearestIdx(IND.pos + IND.baseLeft + IND.baseWid / 2);
    IND.targetPos = visRects[idx].left - IND.baseLeft;
    startLoop();
  }

  function onEnd() {
    const wasDragging = dragging;
    dragging = false; intentDecided = false; _tabbarDragging = false;
    if (IND.mode !== 'drag') return;

    if (!wasDragging) {
      /* 只点了一下滑块没拖动: 回落到当前 tab, 撤销抓取放大 */
      IND.mode = 'flight';
      IND.posSettled = false;
      IND.targetScale = 1;
      const idx = Math.max(0, visNames.indexOf(TAB_NAMES[_curTab]));
      IND.targetPos = visRects[idx].left - IND.baseLeft;
      startLoop();
      return;
    }

    /* 甩动速度: 最近两次 move (px/ms → px/s); 时间窗 120ms 外视为静止 */
    let v = 0;
    if (lastT && prevT && lastT - prevT > 0 && lastT - prevT < 120) {
      v = (lastX - prevX) / (lastT - prevT) * 1000;
    }
    _suppressClick = true; setTimeout(() => { _suppressClick = false; }, 400);
    beginFlight(v);
  }

  /* ── 事件绑定: 触摸 (真机) 与鼠标 (桌面预览/调试) 共用同一套手势逻辑 ── */
  tabbar.addEventListener('touchstart', e => {
    if (e.target.closest('.tab')) tapVibrate();
    const t0 = e.touches[0]; gestureStart(t0.clientX, t0.clientY, e.timeStamp);
  }, { passive: true });
  tabbar.addEventListener('touchmove', e => {
    const t0 = e.touches[0]; gestureMove(t0.clientX, t0.clientY, e.timeStamp);
  }, { passive: true });
  tabbar.addEventListener('touchend',    onEnd);
  tabbar.addEventListener('touchcancel', onEnd);

  let _mouseDown = false;
  tabbar.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    _mouseDown = true;
    gestureStart(e.clientX, e.clientY, e.timeStamp);
  });
  window.addEventListener('mousemove', e => {
    if (!_mouseDown) return;
    gestureMove(e.clientX, e.clientY, e.timeStamp);
  });
  window.addEventListener('mouseup', () => {
    if (!_mouseDown) return;
    _mouseDown = false;
    onEnd();
  });

  /* 点击 tab: 交给 switchTab 统一处理 (内部会通过 _aimIndicator 驱动指示器) */
  tabbar.addEventListener('click', e => {
    const t = e.target.closest('.tab');
    if (!t) return;
    if (_suppressClick) { _suppressClick = false; return; }
    const name = t.id.replace('tab-', '');
    if (name === TAB_NAMES[_curTab]) return;
    switchTab(name);
  });

  /* ── 初始定位 / resize 重置 ──
     left/width 只在这里写一次 (取第一个 tab 的位置与宽度), 之后所有移动只走 transform。
     调用者必须确保 tabbar 此刻无 transform —— 见 cacheRects 的时机约束注释。 */
  window._initIndicator = function() {
    cacheRects();
    if (!visRects.length) return;
    ind.style.transition = 'none';
    ind.style.left   = IND.baseLeft + 'px';
    ind.style.width  = IND.baseWid  + 'px';
    const idx = Math.max(0, visNames.indexOf(TAB_NAMES[_curTab]));
    IND.pos = visRects[idx].left - IND.baseLeft;
    IND.scale = 1;
    IND.targetPos = IND.pos;
    IND.targetScale = 1;
    IND.vel = 0; IND.scaleVel = 0;
    IND.posSettled = true;
    IND.mode = 'idle';
    ind.classList.remove('grabbed');
    render();
  };

  window.addEventListener('resize', () => {
    cacheRects();                       /* tab 宽度可能随视口变化, 先刷新缓存 */
    if (IND.mode !== 'idle') return;
    window._initIndicator();
  });
})();

/* ── DOMContentLoaded ── */
document.addEventListener('DOMContentLoaded', async () => {
  /* 主题回显 */
  try {
    if (localStorage.getItem('turbo-theme') === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    const tb = document.getElementById('theme-btn');
    if (tb) tb.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙';
  } catch (_) {}

  /* 模糊度恢复 (NaN 守卫: localStorage 脏值不再产生 "NaNpx") */
  try {
    const savedOp = localStorage.getItem('turbo-blur');
    const opN = parseInt(savedOp);
    const val = Number.isFinite(opN) ? Math.max(0, Math.min(40, opN)) : 13;
    const sl = document.getElementById('r-opacity');
    const vl = document.getElementById('v-opacity');
    if (sl) { sl.value = val; syncSl(sl); }
    if (vl) vl.textContent = val;
    document.documentElement.style.setProperty('--blur', val + 'px');
  } catch (_) {}

  /* 背景可见度恢复 */
  try {
    const savedBv = localStorage.getItem('turbo-bgvis');
    const bvN = parseInt(savedBv);
    const bv = Number.isFinite(bvN) ? Math.max(0, Math.min(100, bvN)) : 91;
    const bsl = document.getElementById('r-bgvis');
    const bvl = document.getElementById('v-bgvis');
    if (bsl) { bsl.value = bv; syncSl(bsl); }
    if (bvl) bvl.textContent = bv;
    const bg = document.getElementById('bg-layer');
    if (bg) bg.style.opacity = (bv / 100);
  } catch (_) {}

  /* 背景图 */
  try {
    const bgEl = document.getElementById('bg-layer');
    const bimg = new Image();
    bimg.onload = () => { if (bgEl && !bgEl.style.backgroundImage) bgEl.style.backgroundImage = "url('webui.jpg')"; };
    bimg.src = 'webui.jpg';
    if (bgEl && !bgEl.style.backgroundImage) bgEl.style.backgroundImage = "url('webui.jpg')";
  } catch (_) {}

  /* 入场动画 */
  const hdr = document.querySelector('.hdr');
  if (hdr) hdr.classList.add('in');
  document.querySelectorAll('.card, .card-anim').forEach((c, i) => {
    c.style.setProperty('--del', (i * 35) + 'ms');
    c.classList.add('in');
  });

  /* 事件绑定: 短视频包名 (逐个判空, 单点 id 缺失不中断后续初始化/轮询) */
  const on = (id, ev, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(ev, fn); };
  on('add-btn', 'click', addPackage);
  on('pkg-input', 'keydown', e => { if (e.key === 'Enter') addPackage(); });
  on('clear-log', 'click', () => { const lc = document.getElementById('log-content'); if (lc) lc.innerHTML = ''; pkgLog('日志已清空', 'warning'); });
  on('search-input', 'input', e => {
    const kw = e.target.value.trim().toLowerCase();
    renderPackageList(kw ? _packages.filter(p => p.toLowerCase().includes(kw)) : _packages);
  });
  const pListEl = document.getElementById('package-list');
  if (pListEl) pListEl.addEventListener('click', e => {
    const b = e.target.closest('.delete-btn');
    if (b) deletePackage(b.dataset.pkg);
  });
  document.querySelectorAll('#page-config .row .btn[data-pkg]').forEach(b => {
    b.addEventListener('click', () => {
      const inp = document.getElementById('pkg-input');
      inp.value = b.dataset.pkg;
      inp.focus();
    });
  });

  /* 构建标记: 真机若看到的不是这个号, 说明 WebView 还在跑缓存里的旧文件 */
  window._webuiBuild = '110e-20261001';
  if (window.cloudLog) cloudLog('界面构建: ' + window._webuiBuild, 'info');

  /* 首次状态 */
  await Promise.all([refreshStatus(), loadPackages()]);
  const tabbarEl = document.getElementById('tabbar');
  if (tabbarEl) tabbarEl.classList.add('in');

  /* 指示器初始定位: 必须等 tabbar-in 动画结束 —— 动画期间 tabbar 有 scale(.92),
     getBoundingClientRect 返回变换后的坐标, 会把指示器 width/left 写死成缩小版,
     动画结束后视觉上永久对不齐。
     CSS 里已给 .tab-indicator 一个与 tab 等宽的兜底 (calc((100% - 12px) / 4)),
     所以从第一帧到 init 完成之间, 指示器位置都是正确的。 */
  let _indicatorInited = false;
  const initIndicatorOnce = () => {
    if (_indicatorInited) return;
    _indicatorInited = true;
    if (window._initIndicator) window._initIndicator();
  };
  if (tabbarEl) {
    tabbarEl.addEventListener('animationend', (e) => {
      if (e.animationName === 'tabbar-in') initIndicatorOnce();
    }, { once: true });
  }
  /* 兜底: 万一 tabbar-in 动画未触发 (浏览器优化 / 用户禁用了动画), 800ms 后强制 init */
  setTimeout(initIndicatorOnce, 800);

  /* 4s 轮询状态 (页面不可见或不在状态页时跳过: 省电, 不占 ksu 通道) */
  setInterval(async () => {
    try {
      if (document.hidden) return;
      if (TAB_NAMES[_curTab] !== 'status') return;
      if (window._tabbarAnimating) return;   /* 滑块动画中不抢 ksu 通道 */
      await refreshStatus();
    } catch (_) {}
  }, 4000);
});